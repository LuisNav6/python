import calculadora as c
#suma
print("suma:", c.suma(2,3))
#resta
print("resta:", c.resta(2,3))
#multiplicacion
print("multiplicacion:", c.multiplicacion(2,3))
#division
print("division:", c.division(2,3))