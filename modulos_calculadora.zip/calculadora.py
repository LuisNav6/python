def suma(a,b):
    """
    Esta función realiza una suma simple de dos números.

    Parameters:
    a (int): El primer número a sumar.
    b (int): El segundo número a sumar.

    Returns:
    int: El resultado de la suma.
    """
    return a+b

def resta(a,b):
    """
    Esta función realiza una resta simple de dos números.

    Parameters:
    a (int): El primer número a restar.
    b (int): El segundo número a restar.

    Returns:
    int: El resultado de la resta.
    """
    return a-b

def multiplicacion(a,b):
    """
    Esta función realiza una suma simple de dos números.

    Parameters:
    a (int): El primer número a multiplicar.
    b (int): El segundo número a multiplicar.

    Returns:
    int: El resultado de la multiplicacion.
    """
    return a*b

def division(a,b):
    """
    Esta función realiza una suma simple de dos números.

    Parameters:
    a (int): El primer número a dividir.
    b (int): El segundo número a dividir.

    Returns:
    int: El resultado de la division.
    """
    return a/b