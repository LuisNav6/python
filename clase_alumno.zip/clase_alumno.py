class Alumno:
    def __init__(self,nombre,nota):
        self.nombre = nombre
        self.nota = nota
        
    def Mostrardatos(self):
        print("EL nombre del alumno es:", self.nombre, "y su calificación es:", self.nota)
        
    def aprobado(self):
        if(self.nota > 7.0):
            print("EL alumno:", self.nombre, "ha aprobado, con una calificación de:", self.nota)
        else:
            print("EL alumno:", self.nombre, "no ha aprobado, con una calificación de:", self.nota)
            
a1 = Alumno("Juanito",8.5)
a2 = Alumno("Luis",10.0)
a3 = Alumno("Panchito",5.5)
print("Los alumnos que hay registrados son:\n")
a1.Mostrardatos()
print("\n")
a2.Mostrardatos()
print("\n")
a3.Mostrardatos()
print("\n")
a1.aprobado()
a2.aprobado()
a3.aprobado()