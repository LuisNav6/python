class vehiculo:
    color = None
    Ruedas = None
    Puertas = None
    def __init__(self):
        self.color = "blanco"
        self.Puertas = 4
        self.Ruedas = 4
    
    def Iscolor(self):
        return self.color
    
    def IsRuedas(self):
        return self.Ruedas

    def Ispuertas(self):
        return self.Puertas  
    
class coche(vehiculo):
    velocidad = None
    cilindrada = None
    
    def __init__(self):
        super().__init__()
        self.velocidad = 120
        self.cilindrada = 4.0
    
    def Isvelocidad(self):
        return self.velocidad

    def Iscilindrada(self):
        return self.cilindrada
    
c = coche()
print(dir(c))

print("el coche es de color:",  c.Iscolor(), "tiene", c.Ispuertas(), "puertas, tiene", c.IsRuedas(), "ruedas, tiene una velocidad de:", c.Isvelocidad(), "y es de", c.Iscilindrada(), "cilindros!!")
