def bisiesto(a):
    if a % 4 == 0:
        if a % 100 == 0:
            if a % 400 == 0:
                return print(a, "es bisiesto")
            else:
                return print(a, "no es bisiesto")
        else:
            return print(a, "es bisiesto")
    else:
        return print(a, "no es bisiesto")


a = int(input("Dame el año: "))
bisiesto(a)